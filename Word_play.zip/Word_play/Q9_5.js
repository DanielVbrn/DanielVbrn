import * as fs from 'fs'
import prompt from 'prompt-sync'
const input = prompt()

function main(){

    const palavras = loadfile().split("\n")
    console.log(`${palavras.length}`)
    let inicio = "Olá"
    inicio += "\n1 - Com tais letras ."
    inicio += "\n0- sair"
    const n = Number(input("Digite <1> para continuar! \n>" ))
    while(n !== 0){
        if(n == 1){
            com_tais_letras(palavras)
        }
        console.log(inicio)
    }
    function com_tais_letras(palavras){
      const letras_desejadas = input('Insira uma palavra com as letras que deseja: ')
        let c = 0 
        
        for(let palavra of palavras){
            if(uses_all(palavra,letras_desejadas)){
                console.log(palavra)
            }
        }  c++
    
    }
    
    
    function uses_all(palavra,letras_desejadas){
        for(let letras of letras_desejadas){
        if(!contem_letras_desejadas(letras,palavra)){
            return false
        }
        return true
    }
    }
    
    function contem_letras_desejadas(letras,palavra){
        for(let letter of palavra){
            if(letter === letras){
                return true
            }
        }
        return false
    }
    
    
    
    
    function loadfile(){
        try{
            const data = fs.readFileSync('palavras.txt', 'utf-8')
            return data
        } catch (error){
            console.error(error)
        }
    }
    
    
    }
    main()


