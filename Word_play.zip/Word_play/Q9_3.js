import * as fs from 'fs'
import prompt from 'prompt-sync'
const input = prompt()

function main(){

const palavras = loadfile().split("\n")
console.log(`${palavras.length}`)
let entrada = "Hello"
entrada += "\n1 - Letras proibidas."
entrada += "\n0 - Sair"

const inicio = Number(input("Insira <1> para continuar! \n>"))

while(inicio !== 0 ){
    if(inicio == 1){
        Letras_proibidas(palavras)
    }
    console.log(entrada)
}

function Letras_proibidas(palavras){
    const letras_proibidas = input('Digite quais letras serão proibidas proibidas:')  
    let c = 0
    const total = palavras.length
    for(let palavra of palavras){
        if(avoids(palavra, letras_proibidas)){
            
            console.log(`${palavra}`)
            
        }
    }     c++
    const p = (c/total) * 100
    console.log(`E o percentual será: ${p} %`)
}


function avoids(palavra,letras_proibidas){  
    for(let letras of palavra){
        if(contem_letras_P(letras,letras_proibidas)){
            return false   
        }
        
    }  
    return true
}

function contem_letras_P(letras,palavra){
    for(let letter of palavra){
        if(letter === letras){
            return true
        }
    }
    return false
}


function loadfile(){
    try{
        const data = fs.readFileSync('palavras.txt', 'utf-8')
        return data
    } catch (error){
        console.error(error)
    }
}
} 

main()


