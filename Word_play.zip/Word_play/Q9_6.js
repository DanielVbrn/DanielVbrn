import * as fs from 'fs'
import prompt from 'prompt-sync'
const input = prompt()
function main(){
    const palavras = ler_palavras('palavras.txt')
    console.log(`${palavras.length}`)
    
    let start = "Olá"
    start += "\n1- Ordem alfabética."
    start += "\n0- fim."
    let num = Number(input("\nDigite <1> para continuar! \n>"))
    while(num !== 0){
    if(num == 1){
        is_abecedarian()
        }
        console.clear()
        console.log(start)
        num = Number(input("\nDigite <1> para continuar! \n>"))

    }
    

    function is_abecedarian(){
        let c = 0
        let letter = 1
        let proxima_l = letras_alfabeto(letter[c])
        
        const word = input("Digite uma palavra qualquer: ")
        if(proxima_l >= letter){
            letter = proxima_l
            console.log(letter)
            c++
        }else{
            return false
        }
    }

    function letras_alfabeto(caractere){
       let alfabeto = "abcdefghijklmnoprstuvwxyz" 
        for (let item in alfabeto){
            if(alfabeto[item] === caractere){
                return Number(item)+1
            }
        }

    }

    function ler_palavras(nome_arquivos){
        const ler_arquivo = fs.readFileSync(nome_arquivos,{encoding:"utf-8"})
        const carregar  = ler_arquivo
        return carregar
    }





}
main()