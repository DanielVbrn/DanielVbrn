import * as fs from 'fs'
import prompt from 'prompt-sync'
const input = prompt()

function main(){
    const palavras = ler_palavras('palavras.txt')
    console.log(`${palavras.length}`)
    let j = "Olá"
    j += "\n1- Palavras sem a letra e."
    j += "\n0- fim."
    const num = Number(input("\nDigite <1> para continuar! \n>"))
    while(num != 0 ){
        if(num == 1){
            contar_e_mostrar_palavras_sem_e()
        }
        input("Pressione <enter> para retornar a tela de início!")
        console.log(j)
        Number(input("\nDigite <1> para continuar! \n>"))
    }

function contar_e_mostrar_palavras_sem_e(){
    let contar = 0 
    const qtd = palavras.length
    for(let palavra of palavras){
        if(has_no_e(palavra)){
            console.log(palavra)
            contar++
        }
    }
    const percentual = (contar/qtd)*100
    console.log(`O percentual de palavras sem 'e' é igual a :${percentual} %.`)
    console.log(`Tem-se um total de ${qtd} palavras sem a letra 'e'.`)



}

function has_no_e(palavra){ 
    for(let letra of palavra){
            if(letra === 'e'){
                return false
            }
        }
    return true
        

}


function ler_palavras(nome_arquivos){
    const arquivo = fs.readFileSync(nome_arquivos,{encoding:'utf-8'})
    const palavras_carregadas = arquivo.split('\n')
    return palavras_carregadas

    
    
    } 

}
main()