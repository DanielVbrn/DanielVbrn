import prompt from 'prompt-sync'
const input = prompt()

function main(){
    
let inicio = "Olá"
inicio += "\n1 - Com tais letras ."
inicio += "\n0 - Sair."
let n = Number(input("Digite <1> para continuar! \n>" ))
while(n !== 0){
    if(n == 1){
        uses_only()
    }
    console.log(inicio)
}




}
function uses_only(){
    const l = "afjg"
    const palavra = input("Insira uma palavra qualquer que corresponda as letras exigidas: ")
    for( let letra1 of palavra){
        for(let letra2 of l){
            if(letra1 ===letra2){
                console.log(letra1)
                return true
            }
        return false      
        }
    }
    
    
}
main()