import * as fs from 'fs'
import prompt from 'prompt-sync'
const input = prompt()

function main(){
const palavras = ler_palavras('palavras.txt')
console.log(`${palavras.length}`)

let j = "Olá"
j += "\n1- Palavras com mais de 20 letras"
j += "\n0- fim"
const num = Number(input("Digite <1> para continuar! \n>"))
while(num != 0 ){
    if(num == 1){
       Mais_de_vinte_letras(palavras) 
    }
    input("Pressione <enter> para retornar a tela de início!")
    console.log(j)
}



}

function  Mais_de_vinte_letras(palavras) {
let c = 0 
const num = palavras.length
console.log(num)
for (let X of palavras){
        if(X.length >  20){
            console.log(X)
            c++
        }  
    }
   console.log( `Há ${c} palavras com 20 letras ou mais`)
}


function ler_palavras(nome_arquivos){
    const arquivo = fs.readFileSync(nome_arquivos,{encoding:'utf-8'})
    const palavras_carregadas = arquivo.split('\n')
    return palavras_carregadas



} 

main()